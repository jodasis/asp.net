﻿using Examen.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;

namespace Examen.Controllers
{
    [Route("SupermercadoVirtual")]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private List<Item> itemLst;
        private List<Shopping> shoppingList;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        [Route("index")]
        public IActionResult Index()
        {
            ViewBag.itemList = new List<Item> {
                new Item()
                {
                    Id = 1,
                    nombre = "Atún VanCamps",
                    imagen = "atun.jpg",
                    precio = 12
                },
                new Item()
                {
                    Id = 2,
                    nombre = "Queso menonita",
                    imagen = "queso.jpg",
                    precio = 45
                },
                new Item()
                {
                    Id = 2,
                    nombre = "CocaCola",
                    imagen = "soda.jpg",
                    precio = 11
                }

            };
            ViewBag.edad = 18;
            ViewBag.nombre = "David";
            ViewBag.casado = false;
            ViewBag.estatura = 1.75;
            this.itemLst = ViewBag.itemList;
            this.shoppingList = new List<Shopping>();
            Random rnd = new Random();
            double total = 0;
            this.itemLst.ForEach(item =>
            {
                int ran = rnd.Next(1, 7);
                total = total + (ran * item.precio);
                this.shoppingList.Add(new Shopping()
                {
                    Id = 2,
                    nombre = item.nombre,
                    imagen = item.imagen,
                    precioUnitario = item.precio,
                    cantidad = ran,
                    subTotal = item.precio * ran
                });
            });

            HttpContext.Session.SetString("total", total.ToString());

            SessionHelper.setObjetoToJson(HttpContext.Session, "shoppingList", this.shoppingList);

            return View();
        }

        [Route("privacy")]
        public IActionResult Privacy()
        {
            ViewBag.shoppingList = SessionHelper.getJsonToObjeto<List<Shopping>>(HttpContext.Session, "shoppingList");
            ViewBag.total = SessionHelper.getJsonToObjeto<double>(HttpContext.Session, "total");
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        [HttpGet]
        public IActionResult Add(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            Console.WriteLine("id: " + id);
            return View(id);
        }
    }
}
