﻿namespace Examen.Models
{
    public class Shopping
    {
        public int Id { get; set; }
        public string nombre { get; set; }
        public string imagen { get; set; }
        public double precioUnitario { get; set; }
        public int cantidad { get; set; }
        public double subTotal { get; set; }
    }
}
